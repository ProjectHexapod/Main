"""Collects the various WGL extensions together"""
from OpenGL.raw._GLX import *
from OpenGL.raw._GLX_ARB import *
from OpenGL.raw._GLX_NV import *