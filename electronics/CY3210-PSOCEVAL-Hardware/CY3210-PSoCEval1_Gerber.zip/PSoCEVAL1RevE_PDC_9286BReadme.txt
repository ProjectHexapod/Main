From:		Foothill Services LLC
                6616 NE 198th Street
               	Kenmore WA 98028-3404
                (206) 853-8470
                foothill@foothillpcb.com

Date:		10/31/2006

Customer:	Cypress Semiconductor Boise
		Contact: Steve Narum
		(208) 489-9382

		
P.O. #:		TBD


Good day;

Attached are files for PCB named "PSoCEVAL1RevE_PDC9286B". 

Please review Gerber Drill and Trim file (PSoCEVAL1RevE_PDC9286B.GD1) for 
fabrication notes.

If there are any CAD questions please call Brian Sherer
at cellphone (206) 853-8470.

Engineering contact is Mr. Steve Narum at Cypress Semiconductor, Boise.

Thanks!

Brian



Files were generated in Protel DesignerSP4.
Included are:

=================================================================

			EXTENSION	FILE CONTENTS

<PSoCEVAL1RevE_PDC9286B>.GTO		TOP OVERLAY
			.GTS		TOP SOLDERMASK
			.GTL		TOP LAYER
			.GBL		BOTTOM LAYER
			.GBS		BOTTOM SOLDERMASK

			.GD1		DRILL AND TRIM DRAWING/FAB NOTES

			.DRL		DRILL DATA
			
PSoCEVAL1RevE_PDC9286BReadme.TXT	THIS FILE
=================================================================
